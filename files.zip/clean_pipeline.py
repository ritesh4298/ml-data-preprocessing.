"""
Data preprocessing walkthrough: student placement dataset
Run:  python clean_pipeline.py
"""
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

# 1. Load and inspect
df = pd.read_csv("student_placement_raw.csv")
print(df.shape)
df.info()
print(df[["cgpa", "attendance_pct", "study_hours_per_day", "family_income"]].describe().round(1))

# 2. Audit
print(df.isnull().sum())
print("Duplicate rows:", df.duplicated().sum())
print(df["branch"].value_counts())
print(df["gender"].value_counts())

# 3. Remove duplicates
df = df.drop_duplicates().reset_index(drop=True)

# 4. Fix inconsistent text
df["branch"] = df["branch"].str.strip().str.upper().replace({"CIVIL": "Civil"})
df["gender"] = df["gender"].str.strip().str.title()

# 5. Impossible values -> NaN
df.loc[df["attendance_pct"] > 100, "attendance_pct"] = np.nan
df.loc[df["study_hours_per_day"] > 12, "study_hours_per_day"] = np.nan

# 6. Missing values
df["city_type"] = df["city_type"].fillna(df["city_type"].mode()[0])
df["age"] = df["age"].fillna(df["age"].median())
for col in ["cgpa", "attendance_pct", "study_hours_per_day"]:
    df[col] = df[col].fillna(df.groupby("branch")[col].transform("median"))
df["family_income"] = df["family_income"].fillna(df["family_income"].median())

# 7. Data types
df[["age", "internships", "backlogs"]] = df[["age", "internships", "backlogs"]].astype(int)

# 8. Outliers (IQR capping)
q1, q3 = df["family_income"].quantile([0.25, 0.75])
iqr = q3 - q1
lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
df["family_income"] = df["family_income"].clip(lower, upper)

# 9. Quick EDA
df["placed_bin"] = (df["placed"] == "Yes").astype(int)
print(df.select_dtypes("number").drop(columns="student_id").corr()["placed_bin"].round(2))

# 10. Feature selection
df = df.drop(columns=["student_id", "college_code"])

# 11. Encoding
df["gender"] = df["gender"].map({"Male": 0, "Female": 1})
df["city_type"] = df["city_type"].map({"Rural": 0, "Semi-Urban": 1, "Urban": 2})
df = pd.get_dummies(df, columns=["branch"], dtype=int)
df = df.drop(columns="placed").rename(columns={"placed_bin": "placed"})

# 12. Transform and scale
df["family_income_log"] = np.log1p(df["family_income"])
df = df.drop(columns="family_income")
to_scale = ["age", "cgpa", "attendance_pct", "study_hours_per_day", "family_income_log"]
df[to_scale] = StandardScaler().fit_transform(df[to_scale])

# 13. Save and verify
assert df.isnull().sum().sum() == 0
df.to_csv("student_placement_clean.csv", index=False)
print(df.shape)
